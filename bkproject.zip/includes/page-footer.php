<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/navigation.js"></script>
<script src="assets/js/pageparams.js"></script>
<script src="assets/js/swiper-bundle.min.js"></script>
<script src="assets/js/common.js"></script>
<script src="assets/js/safe-food.js"></script>
<script src="assets/js/jput.js"></script>
<script src="assets/js/jquery-ui.min.js" type="text/javascript"></script>