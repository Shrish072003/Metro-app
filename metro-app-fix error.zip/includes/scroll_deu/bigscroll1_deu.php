<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="stylesheet" href="../../assets/prev/css/page2_style.css">
  <script src="https://code.jquery.com/jquery-2.2.4.js"></script>
  <script src="../../assets/prev/jquery/custom.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
  <link rel="stylesheet" href="../../assets/css/navigation.css">
  <link href="../../assets/css/normalize.min.css" rel="stylesheet">
  <link href="../../assets/css/style1.css" rel="stylesheet">
  <link href="../../assets/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">

  <link rel="apple-touch-icon" sizes="180x180" href="../../assets/images/icon-180x180.png">
  <link rel="icon" type="image/png" sizes="32x32" href="../../assets/images/icon-32x32.png">
  <link rel="mask-icon" href="../..//safari-pinned-tab.svg" color="#5bbad5">
  <link rel="stylesheet" href="../../assets\css\responsive.css">
  <!--META TAGS-->
  <meta name="msapplication-TileColor" content="#603cba">
  <meta name="theme-color" content="#ffffff">
  <meta name="robots" content="noindex,nofollow">
  <style>
    .section-lena-inner {
      padding-left: 0;
    }

    body {
      overflow: auto;
    }

    nav.navbar {
      height: 60px;
      top: 0;
    }

    .c9 {
      padding-left: 0 !important;
      padding-right: 0 !important;
      max-width: 100%;
    }

    .likebtn {
      margin-bottom: 2rem;
    }

    .spacerx {
      margin-top: 3rem;
    }

    .nodeco {
      color: white !important;
      text-decoration: none !important;
    }

    .nowrap1 {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    @media print {
      body * {
        visibility: hidden;
      }

      .section-to-print,
      .section-to-print * {
        visibility: visible;
      }

      .section-to-print {
        position: absolute;
        left: 0;
        top: 0;
      }
    }

    .section1 {
      margin-top: 4rem;
      background-color: white;
    }

    .w100p {
      width: 100% !important;
      max-width: 100% !important;
    }

    .mid-highlight.container {
      max-width: 100%;
    }

    .section-lena-kitchen {
      max-width: 100%;
    }

    .section-simple-way {
      background-color: white;
    }

    .page-3_stage.page-4_stage {
      background-color: white;
    }
    .item.slick-slide {
    width: 280px;
    height: 450px !important;
    transition: transform 0.4s;
    position: relative;
}
.custom__select:before{
            background:#ffe500;
        }
        nav.navbar {
      height: 60px;
      top: 0;
    }
        .search-btn{    margin-right: 0px;
     }
     .custom__select:before {
    right: 5px !important;
    top: 3px;
}
.custom__select select {
    color: #ffe500;
    padding-left: 4px;
}
.slick-slide img {
    display: block !important;
    width: auto;
    max-height: 250px !important;
    object-fit: contain !important;

}
.section-slider1 {
    margin-top: auto;
}
.footer-wrap {
    position: relative !important;
}
.inner-item {
    background-color: #ffffff;
    background-image: none !important;
}
.section-slider2 .slick-slide:after {
    background: none !important;
    background-color: #DDDDDD !important;
}
.wrap {
    background: transparent !important;
    margin-bottom: 100px;
}
.inner-item button {
    background-color: #003b7e !important;
    height: 40px !important;
    font-size: 18px !important;
    width: 160px;
    color: #fff !important;
    padding-top: 10px !important;
}
.section-slider-center h3, .top-content h3 {
    padding: 0px 0 10px !important;
}
.modal-content1 img{
    margin-bottom: 20px;
}
.modal-content1 .read-more-btn{
    background-color: #ffe500 !important;
    margin-right: auto;
    margin-left: auto;
    font-size: 18px;
    color: #fff;
}
.slick-slide{
  background-image:none !important;
}
.modal-wrapper1 {
    height: 70% !important;
}
.section-slider-center h3 {
        text-transform: capitalize;
        font-size: 25px !important;
    }
    .read-more-btn {
    width: 180px !important;
}
  </style>
<section class="section-slider1 section-slider2 no-print">
        <div class="section-slider-center text-center">
          <div class="wrap" style="z-index: 0;">
            <div class="slider2">
              <div class="item">
                <div class="inner-item">
                    <h3>VERSCHIEDENE
ABFALLARTEN IDENTIFIZIEREN</h3>
                    <img src='assets/images/safe_food/fw-2.svg?width="54px"%20height="54px"' />
                    <button class="modal-toggle15 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>LAGERN SIE OBST
UND GEMÜSE RICHTIG</h3>
                    <img src="assets/images/safe_food/fw-3.svg" />
                  <button class="modal-toggle9 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                <h3>ORDERN SIE NUR SOLCHE WAREN,
DIE SIE WIRKLICH BRAUCHEN</h3>
                    <img src="assets/images/safe_food/fw-4.svg" />
                  <button class="modal-toggle8 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>ACHTEN SIE AUF GUTE QUALITÄT</h3>
                    <img src="assets/images/safe_food/fw-5.svg" />
                  <button class="modal-toggle10 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>KOMPOSTIEREN SIE DIE RESTE</h3>
                    <img src="assets/images/safe_food/fw-6.svg" />
                  <button class="modal-toggle12 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>SPENDEN SIE ÜBERSCHÜSSIGE LEBENSMITTEL</h3>
                    <img src="assets/images/safe_food/fw-7.svg" />
                  <button class="modal-toggle13 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>BEZIEHEN
SIE IHR PERSONAL EIN</h3>
                    <img src="assets/images/safe_food/fw-1.svg" />
                  <button class="modal-toggle14 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>
<!-- 
              <div class="item">
                <div class="inner-item">
                    <h3>Sustainable Menu</h3>
                    <img src="assets\images\the-msr-chapter\msr_7.png" />
                  <button class="modal-toggle15 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>Social</h3>
                    <img src="assets\images\the-msr-chapter\msr_8.png" />
                  <button class="modal-toggle16 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>Water</h3>
                    <img src="assets\images\the-msr-chapter\msr_9.png" />
                  <button class="modal-toggle17 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div> -->


              <!-- <div class="item">
                <div class="inner-item">
                    <h3>Responsible Sourcing</h3>
                    <img src="assets\images\the-msr-chapter\msr_10.png" />
                  <button class="modal-toggle18 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div> -->


            </div>
          </div>

        </div>
      </section>

  <div class="eng-modal">
    <div class="modal-overlay1 modal-toggle8"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle8">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4> Ordern Sie nur solche Waren, die Sie wirklich brauchen </h4>
            <p>Vermeiden Sie von vornherein, Lebensmittel zu verschwenden. Kaufen Sie nur das ein, was Sie auch wirklich verbrauchen </p>
        </div>
      </div>
    </div>
  </div>

  <div class=" redu-modal">
    <div class="modal-overlay1 modal-toggle9"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle9">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4> Lagern Sie Obst und Gemüse richtig </h4>
            <p> Obst und Gemüse tragen wesentlich zu der Menge von Lebensmittelabfällen in Ihrem Restaurant bei. Prüfen Sie deshalb, ob Sie bereits alle Maßnahmen zur Lagerung von Obst und Gemüse ausschöpfen, um unnötige Lebensmittelabfälle zu vermeiden:


            <ul>
                <li>Stellen Sie sicher, dass Ihr Lagerraum gut belüftet ist.
                </li>
                <li>Wenden Sie das First-In-First-Out-Prinzip (FIFO) an, um sicherzugehen, dass Produkte, die zuerst angeliefert werden, auch sofort weiterverarbeitet werden.
                </li>
                <li>Lagern Sie Obst und Gemüse bei einer niedrigeren Temperatur als in der Umgebung, in er sie normalerweise wachsen, um ihre Haltbarkeit zu verlängern.
                </li>
                <li>Lagern Sie Obst und Gemüse entsprechend ihren spezifischen Lagertemperaturen. Beeren können z. B. in einem Kühlschrank aufbewahrt werden, Bananen sollten jedoch außerhalb des Kühlschranks an einem kühlen Ort gelagert werden.
                </li>
                <li>Frische Produkte sollten ihre spezifische Temperaturzone nicht zu lange verlassen. Abgepackte Salate verlieren einen Tag ihrer Haltbarkeit für jede Stunde, die sie nicht optimal gelagert werden.</li>
                <li>Gehen Sie vorsichtig mit Obst und Gemüse um, um Beschädigungen zu vermeiden.
                </li>
                <li>Stapeln Sie leichte Waren wie Beeren, Pilze und leichte Kisten oben im Kühlschrank und Kühlraum.
                </li>
                <li>Achten Sie auf verpackte Produkte, wie z. B. Äpfel in einer Plastikfolie, da die Beschädigung eines Produkts in der Verpackung auch die anderen schnell beschädigen kann.
                </li>
                <li>Trennen Sie Ethylen produzierende Produkte (Bananen, Äpfel, Birnen, Kiwis, Feigen, Melonen und Tomaten) von ethylempfindlichen Produkten (Zitrusfrüchte, Ananas, Blattgemüse, Kirschen, Beeren, Trauben sowie Fruchtgemüse). Durch die Trennung wird die Reifung der ethylempfindlichen Lebensmittel verlangsamt.
                </li>
            </ul>
            </p>
        </div>
        
      </div>
    </div>
  </div>



  <div class=" set-modal">
    <div class="modal-overlay1 modal-toggle13"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle13">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4> Spenden Sie überschüssige Lebensmittel </h4>
            <p>Nicht verwendete Lebensmittel müssen nicht weggeworfen werden. Indem Sie solche Lebensmittel spenden oder günstiger anbieten (z. B. über <a href="https://toogoodtogo.at/de-at" target="_blank">TOO GOOD TO GO</a>), verhindern Sie, dass diese auf der Mülldeponie landen. Gleichzeitig helfen Sie Menschen in Not. Darüber hinaus steigern Spenden die Moral Ihres Personals, weil Ihre Mitarbeitenden sehen, dass sie etwas Positives bewirken. Spenden können Ihnen auch bei der Steuer finanzielle Vorteile bringen. Grundsätzlich können Lebensmittel an Wohltätigkeitsorganisationen, Lebensmittelbanken, Zoos oder Tierheime gespendet werden. Aber denken Sie daran: In der Regel stellen diese bestimmte Anforderungen an die Lebensmittel, die sie annehmen. Dies sind zum Beispiel:
            <ul>
                <li>Frische Lebensmittel müssen verpackt und noch haltbar sein
                </li>
                <li>Obst und Gemüse darf nicht verdorben sein
                </li>
                <li>Verpackte Lebensmittel müssen ungeöffnet sein </li>
            </ul>

            </p></div>
      </div>
    </div>
  </div>


  <div class=" ver-modal">
    <div class="modal-overlay1 modal-toggle14"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle14">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Beziehen Sie Ihr Personal ein</h4>
            <p> Wenn Sie versuchen, möglichst wenig Lebensmittel zu verschwenden, sollten Sie Ihr Personal miteinbinden. Machen Sie ihnen die Bedeutung der Abfallvermeidung in Ihrem Betrieb verständlich. Das Engagement Ihres Personals ist entscheidend dafür, dass alle Maßnahmen funktionieren. Sie müssen auf dem Laufenden gehalten und geschult werden. Führen Sie mehrfache Schulungen durch, platzieren Sie Informationen zur Abfallvermeidung an gut sichtbaren Stellen und erinnern Sie alle immer wieder daran, dass die Unterstützung jedes einzelnen Mitarbeitenden zählt, um die Lebensmittelverschwendung im Arbeitsalltag der Gastronomie zu bekämpfen.
            </p>
        </div>
      </div>
    </div>
  </div>

  <div class=" exp-modal">
    <div class="modal-overlay1 modal-toggle15"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle15">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Verschiedene Abfallarten identifizieren </h4>
            <p> Lebensmittelabfälle sind in der Gastronomie allgegenwärtig, aber Sie können einfache Maßnahmen ergreifen, um sie zu reduzieren. Beginnen Sie damit, die verschiedenen Abfallarten in Ihrem Restaurant zu identifizieren und stellen Sie fest, wo diese anfallen. Allgemein entstehen Lebensmittelabfälle entweder im hinteren Teil Ihres Restaurants (z. B. im Lager oder in der Küche) oder im vorderen Teil (z. B. dort, wo die Gäste bedient werden). Prüfen Sie, wie viel Lebensmittelabfälle Sie in Ihrem Restaurant produzieren und ermitteln Sie, wo diese Lebensmittel unnötig weggeworfen werden.
            </p>
            <div class="row mt-4">
                <div class="col-md-6">
                    <h6><strong>Lebensmittelabfälle im hinteren Bereich des Restaurants</strong></h6>
                    <ul>
                        <li> Messen, verfolgen und analysieren Sie Ihre Lebensmittelabfälle</li>
                        <li> Prüfen Sie Ihre Speisekarte. Entfernen Sie Gerichte, die sich nicht gut verkaufen</li>
                        <li> Nutzen Sie digitale Tools, wie das <a href="https://www.menukithd.com/" target="_blank">Menukit </a>, um Rezepte zu verwalten und den täglichen Bedarf an Lebensmitteln zu berechnen. So können Sie gleichzeitig Ihre Einkaufskosten besser kontrollieren.</li>
                        <li> Fragen Sie Ihre Mitarbeitenden nach ihrer Einschätzung: Wo werden Lebensmittel verschwendet und wie kann man es vermeiden?
                        </li>
                        <li> Optimieren Sie die Haltbarkeit von Lebensmitteln, indem Sie sicherstellen, dass die Kühlketten nicht unterbrochen und die Produkte bei der richtigen Temperatur gelagert werden.
                        </li>
                        <li>Organisieren und beschriften Sie Ihre Vorräte, so dass die Haltbarkeit sichtbar ist.
                        </li>
                        <li>Stellen Sie sicher, dass alle bereits geöffneten und verarbeiteten Zutaten ein Etikett mit ihrer Haltbarkeitsdauer erhalten.
                        </li>
                        <li>Sorgen Sie für Ordnung in Ihrem Vorratsraum. Sie sollten immer wissen, was verbraucht werden muss, damit Sie nicht mehr bestellen, als wirklich nötig ist.</li>
                        <li>Überprüfen Sie Ihren Bestand regelmäßig, um die gekauften Mengen und die Menge der verschwendeten Lebensmittel zu vergleichen.
                        </li>
                        <li>Versuchen Sie, bislang nicht verwendete Teile von Lebensmitteln zu nutzen, z. B. mit Hilfe von <a href="https://www.mpulse.de/de/gastronomie/food-trends-fuer-die-gastronomie" target="_blank"> Zero-Waste-Rezepten.</a>
                        </li>
                        <li> Bedenken Sie, dass Lebensmittelreste (die nicht von Tieren stammen) als Tierfutter gespendet werden können, z. B. an ein örtliches Tierheim oder einen Zoo.
                        </li>
                        <li> Erlauben Sie Ihrem Personal, die überschüssigen Lebensmittel am Ende des Tages zu essen oder mit nach Hause zu nehmen.</li>
                        <li>Spenden Sie Ihre übrig gebliebenen Lebensmittel.
                        </li>
                        <li> Recyceln und/oder verwerten Sie Abfälle, wo immer es möglich ist.</li>
                        <li>Rausnehmen, aber den Link übernehmen.
                        </li>


                    </ul>
                </div>

                <div class="col-md-6">
                    <h6><strong>Lebensmittelabfälle im vorderen Bereich des Restaurants
                        </strong></h6>
                    <ul>
                        <li> Überwachen Sie die Portionsgrößen der Gerichte. Prüfen Sie, ob Sie die Mengen ändern sollten, wenn zu viele Reste pro Gast anfallen
                        </li>
                        <li> Erwägen Sie die Verwendung kleinerer Teller</li>
                        <li> Analysieren Sie die Beliebtheit einzelner Gerichte </li>
                        <li> Ermutigen Sie Ihre Gäste, Essensreste mitzunehmen</li>
                        <li> Legen Sie mit Ihrem Personal die genauen Portionsgrößen pro Gericht fest
                        </li>
                        <li> Überarbeiten Sie Ihre Speisekarte, um die Menge der Lebensmittelreste zu reduzieren
                        </li>
                        <li> Geben Sie Rabatte an Ihre Gäste weiter, wenn Sie übriggebliebene Lebensmittel verwenden
                        </li>
                        <li> Spenden Sie Ihre überschüssigen Lebensmittel, wenn Sie sie nicht weiterverkaufen können</li>
                        <li> Trennen Sie Ihre Lebensmittelabfälle ordnungsgemäß, damit sie richtig verarbeitet werden können
                        </li>
                        <li> Kompostieren Sie Ihre Lebensmittel, wenn möglich
                        </li>
                        <li> Informieren Sie Ihre Gäste über Ihre Maßnahmen
                        </li>

                    </ul>
                </div>
                </div></div>
      </div>
    </div>
  </div>


  <div class=" neh-modal">
    <div class="modal-overlay1 modal-toggle16"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle16">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
          <h4>Why gastronomy must engage socially </h4>
          <img src="assets/prev/images/L2-09.svg" />
          <p>When your staff is treated well, the positive effects on your business are felt not only in your restaurant but also in the community around you. As a restaurant owner, you have direct responsibility for your employees, but you also have indirect responsibility for every worker in the supply chain - the community overall. Take an active role in your community and ensure the welfare of your employees, your customers, your suppliers, and others in society whom you are in touch with.</p>
          <button class="read-more-btn" href="introduction-to-social-eng.php">
        TAKE A DEEP DIVE 
                  </button></div>
      </div>
    </div>
  </div>



  <div class=" setsie-modal">
    <div class="modal-overlay1 modal-toggle17"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle17">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">
        <div class="modal-content1 flexi-cont">
          <h4>How to save water in your restaurant</h4>
          <img src="assets/prev/images/L2-01.svg" />
          <p>Water runs your business. As a restaurant owner, you require a large amount of it before, during and after the service, from cooking and steaming to washing and sanitizing. But water does not only cost you money, it is also precious. Show your customers that you take responsibility and adapt water saving behavior with long-term benefits for you and the environment. </p>
          <button class="read-more-btn" href="introduction-to-water-eng.php">
        TAKE A DEEP DIVE 
                  </button>
        </div>
      </div>
    </div>
  </div>

  <div class="introdiv-modal">
    <div class="modal-overlay1 modal-toggle18"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle18">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
          <h4>
            Introduce diverse grains
          </h4>
          <p>Use ancient varieties of grains such as teff or those that are common to your region.
          </p>
        </div>
      </div>
    </div>
  </div>


  <div class=" intro-modal">
    <div class="modal-overlay1 modal-toggle10"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle10">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4> Achten Sie auf gute Qualität </h4>
            <p>Seien Sie offen für leichte Mängel an Lebensmitteln, aber meiden Sie Gemüse und Obst, das zu viele Druckstellen oder Schäden aufweist.</p></div>
      </div>
    </div>
  </div>
  <div class=" source-modal">
    <div class="modal-overlay1 modal-toggle11"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle11">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
          <h4>
            <a class="nodeco" href="introduction-to-responsible-sourcing-eng.php">Source locally, regionally and in season
</a>
          </h4>
          <p>Make an impact with responsible sourcing and only use responsibly sourced fish and food that is organic, nutritious, seasonal, ethically traded, local and regional. Moreover, try to buy foods that encourage biodiversity, do not involve waste and do not destroy forests. If you want to find out more, go to the responsible sourcing chapter. </p>
        </div>
      </div>
    </div>
  </div>

  <div class=" use-modal">
    <div class="modal-overlay1 modal-toggle12"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle12">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont more-text">
          <div>
          <h4>Kompostieren Sie die Reste </h4>
            <p> Die Kompostierung kann dazu beitragen, Lebensmittelreste zu verwerten und die Methanemissionen in Mülldeponien zu verringern. Obst, Gemüse, Kaffee und Tee eignen sich allesamt hervorragend für den Kompost.</p>


          </div>
        </div>
      </div>
    </div>


    <script>
      var x, i, j, l, ll, selElmnt, a, b, c;
      /*look for any elements with the class "custom-select":*/
      x = document.getElementsByClassName("custom-select");
      l = x.length;
      for (i = 0; i < l; i++) {
        selElmnt = x[i].getElementsByTagName("select")[0];
        ll = selElmnt.length;
        /*for each element, create a new DIV that will act as the selected item:*/
        a = document.createElement("DIV");
        a.setAttribute("class", "select-selected");
        a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
        x[i].appendChild(a);
        /*for each element, create a new DIV that will contain the option list:*/
        b = document.createElement("DIV");
        b.setAttribute("class", "select-items select-hide");
        for (j = 1; j < ll; j++) {
          /*for each option in the original select element,
          create a new DIV that will act as an option item:*/
          c = document.createElement("DIV");
          c.innerHTML = selElmnt.options[j].innerHTML;
          c.addEventListener("click", function(e) {
            /*when an item is clicked, update the original select box,
            and the selected item:*/
            var y, i, k, s, h, sl, yl;
            s = this.parentNode.parentNode.getElementsByTagName("select")[0];
            sl = s.length;
            h = this.parentNode.previousSibling;
            for (i = 0; i < sl; i++) {
              if (s.options[i].innerHTML == this.innerHTML) {
                s.selectedIndex = i;
                h.innerHTML = this.innerHTML;
                y = this.parentNode.getElementsByClassName("same-as-selected");
                yl = y.length;
                for (k = 0; k < yl; k++) {
                  y[k].removeAttribute("class");
                }
                this.setAttribute("class", "same-as-selected");
                break;
              }
            }
            h.click();
          });
          b.appendChild(c);
        }
        x[i].appendChild(b);
        a.addEventListener("click", function(e) {
          /*when the select box is clicked, close any other select boxes,
          and open/close the current select box:*/
          e.stopPropagation();
          closeAllSelect(this);
          this.nextSibling.classList.toggle("select-hide");
          this.classList.toggle("select-arrow-active");
        });
      }

      function closeAllSelect(elmnt) {
        /*a function that will close all select boxes in the document,
        except the current select box:*/
        var x, y, i, xl, yl, arrNo = [];
        x = document.getElementsByClassName("select-items");
        y = document.getElementsByClassName("select-selected");
        xl = x.length;
        yl = y.length;
        for (i = 0; i < yl; i++) {
          if (elmnt == y[i]) {
            arrNo.push(i)
          } else {
            y[i].classList.remove("select-arrow-active");
          }
        }
        for (i = 0; i < xl; i++) {
          if (arrNo.indexOf(i)) {
            x[i].classList.add("select-hide");
          }
        }
      }
      /*if the user clicks anywhere outside the select box,
      then close all select boxes:*/
      document.addEventListener("click", closeAllSelect);



      $('.slider').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        arrows: true,
        dots: false,
        centerMode: true,
        variableWidth: true,
        infinite: true,
        focusOnSelect: true,
        cssEase: 'linear',
        touchMove: true,
        prevArrow: '<button class="slick-prev"> < </button>',
        nextArrow: '<button class="slick-next"> > </button>',

        //         responsive: [                        
        //             {
        //               breakpoint: 576,
        //               settings: {
        //                 centerMode: false,
        //                 variableWidth: false,
        //               }
        //             },
        //         ]
      });



      var imgs = $('.slider img');
      imgs.each(function() {
        var item = $(this).closest('.item');
        item.css({
          'background-image': 'url(' + $(this).attr('src') + ')',
          'background-position': 'center',
          '-webkit-background-size': 'cover',
          'background-size': 'cover',
        });
        $(this).hide();
      });

      $('.slider2').slick({
        slidesToShow: 3,
        arrows: true,
        dots: false,
        centerMode: true,
        variableWidth: true,
        infinite: true,
        focusOnSelect: true,
        cssEase: 'linear',
        touchMove: true,
        prevArrow: '<button class="slick-prev"> < </button>',
        nextArrow: '<button class="slick-next"> > </button>',

        //         responsive: [                        
        //             {
        //               breakpoint: 576,
        //               settings: {
        //                 centerMode: false,
        //                 variableWidth: false,
        //               }
        //             },
        //         ]
      });

      var imgs = $('.slider2 img');
      imgs.each(function() {
        var item = $(this).closest('.item');
        item.css({
          'background-image': 'url(' + $(this).attr('src') + ')',
          'background-position': 'center',
          '-webkit-background-size': 'cover',
          'background-size': 'cover',
        });
        $(this).hide();
      });




      let collapsibleHeaders = document.getElementsByClassName('collapsible__header');

      Array.from(collapsibleHeaders).forEach(header => {
        header.addEventListener('click', () => {
          header.parentElement.classList.toggle('collapsible--open');
        });
      });

      // Quick & dirty toggle to demonstrate modal toggle behavior
      $('.modal-toggle1').on('click', function(e) {
        e.preventDefault();
        $('.vegan-modal').toggleClass('is-visible');
      });
      $('.modal-toggle2').on('click', function(e) {
        e.preventDefault();
        $('.vegi-modal').toggleClass('is-visible');
      });
      $('.modal-toggle3').on('click', function(e) {
        e.preventDefault();
        $('.paleo-modal').toggleClass('is-visible');
      });
      $(' .modal-toggle4').on('click', function(e) {
        e.preventDefault();
        $('.keto-modal').toggleClass('is-visible');
      });
      $('.modal-toggle5').on('click', function(e) {
        e.preventDefault();
        $('.fruit-modal').toggleClass('is-visible');
      });
      $('.modal-toggle6').on('click', function(e) {
        e.preventDefault();
        $('.omni-modal').toggleClass('is-visible');
      });
      $('.modal-toggle7').on('click', function(e) {
        e.preventDefault();
        $('.flexi-modal').toggleClass('is-visible');
      });
      $('.modal-toggle8').on('click', function(e) {
        e.preventDefault();
        $('.eng-modal').toggleClass('is-visible');
      });
      $('.modal-toggle9').on('click', function(e) {
        e.preventDefault();
        $('.redu-modal').toggleClass('is-visible');
      });
      $('.modal-toggle10').on('click', function(e) {
        e.preventDefault();
        $('.intro-modal').toggleClass('is-visible');
      });
      $('.modal-toggle11').on('click', function(e) {
        e.preventDefault();
        $('.source-modal').toggleClass('is-visible');
      });
      $('.modal-toggle12').on('click', function(e) {
        e.preventDefault();
        $('.use-modal').toggleClass('is-visible');
      });

      $('.modal-toggle13').on('click', function(e) {
        e.preventDefault();
        $('.set-modal').toggleClass('is-visible');
      });
      $('.modal-toggle14').on('click', function(e) {
        e.preventDefault();
        $('.ver-modal').toggleClass('is-visible');
      });
      $('.modal-toggle15').on('click', function(e) {
        e.preventDefault();
        $('.exp-modal').toggleClass('is-visible');
      });
      $('.modal-toggle16').on('click', function(e) {
        e.preventDefault();
        $('.neh-modal').toggleClass('is-visible');
      });
      $('.modal-toggle17').on('click', function(e) {
        e.preventDefault();
        $('.setsie-modal').toggleClass('is-visible');
      });

      $('.modal-toggle18').on('click', function(e) {
        e.preventDefault();
        $('.introdiv-modal').toggleClass('is-visible');
      });
    </script>