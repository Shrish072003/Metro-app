  <link rel="stylesheet" href="slider.css">
  <!--META TAGS-->
  <meta name="msapplication-TileColor" content="#603cba">
  <meta name="theme-color" content="#ffffff">
  <meta name="robots" content="noindex,nofollow">
  <style>
    .section-lena-inner {
      padding-left: 0;
    }

    body {
      overflow: auto;
    }

    nav.navbar {
      height: 60px;
      top: 0;
    }

    .c9 {
      padding-left: 0 !important;
      padding-right: 0 !important;
      max-width: 100%;
    }

    .likebtn {
      margin-bottom: 2rem;
    }

    .spacerx {
      margin-top: 3rem;
    }

    .nodeco {
      color: white !important;
      text-decoration: none !important;
    }

    .nowrap1 {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    @media print {
      body * {
        visibility: hidden;
      }

      .section-to-print,
      .section-to-print * {
        visibility: visible;
      }

      .section-to-print {
        position: absolute;
        left: 0;
        top: 0;
      }
    }

    .section1 {
      margin-top: 4rem;
      background-color: white;
    }

    .w100p {
      width: 100% !important;
      max-width: 100% !important;
    }

    .mid-highlight.container {
      max-width: 100%;
    }

    .section-lena-kitchen {
      max-width: 100%;
    }

    .section-simple-way {
      background-color: white;
    }

    .page-3_stage.page-4_stage {
      background-color: white;
    }
    .item.slick-slide {
    width: 280px;
    height: 450px !important;
    transition: transform 0.4s;
    position: relative;
}
.custom__select:before{
            background:#ffe500;
        }
        nav.navbar {
      height: 60px;
      top: 0;
    }
        .search-btn{    margin-right: 0px;
     }
     .custom__select:before {
    right: 5px !important;
    top: 3px;
}
.custom__select select {
    color: #ffe500;
    padding-left: 4px;
}
.slick-slide img {
    display: block !important;
    width: auto;
    max-height: 150px !important;
    object-fit: contain !important;
}
.section-slider2 .inner-item button {
    padding-top: 0;
    display: table;
    margin-right: auto;
    margin-left: auto;
    border-radius: 50px;
}
.section-slider1 {
    margin-top: auto;
}
.footer-wrap {
    position: relative !important;
}
.inner-item {
    background-color: #ffffff;
    background-image: none !important;
}
.section-slider2 .slick-slide:after {
    background: none !important;
    background-color: #DDDDDD !important;
}
.wrap {
    background: transparent !important;
    margin-bottom: 100px;
}
.inner-item button {
    background-color: #003b7e !important;
    height: 40px !important;
    font-size: 18px !important;
    width: 160px;
    color: #fff !important;
    padding-top: 10px !important;
}
.section-slider-center h3, .top-content h3 {
    font-size: 32px;
    padding: 0px 0 10px !important;
}
.modal-content1 img{
    margin-bottom: 20px;
}
.modal-content1 .read-more-btn{
    background-color: #ffe500 !important;
    margin-right: auto;
    margin-left: auto;
    font-size: 18px;
    color: #fff;
}
.slick-slide{
  background-image:none !important;
}
.modal-wrapper1 {
    height: 70% !important;
}
.section-slider-center h3 {
    text-transform: capitalize;
    font-size: 20px !important;
}
.read-more-btn {
    width: 170px !important;
}
  </style>
<section class="section-slider1 section-slider2 no-print">
<div class="simple_wayTo_preventing no-print energy_page_slider" id="option3" data-scrl="Simple ways to save energy">
<div class="section-div">
                    <div class="container-fluid">
                        <h3 class="wayT0Title">Tipps für Einsteiger, um Energie zu sparen</h3>
                        <p class="disc">Als Gastronomin oder Gastronom gibt es viele Möglichkeiten, wie Sie in
Ihrem Restaurant Energie sparen können. Einige Maßnahmen können Sie sofort umsetzen. So können Sie anfangen:</p>
                       </div>
                </div>
                </div>
        <div class="section-slider-center text-center">
          <div class="wrap" style="z-index: 0;">
            <div class="slider2">
              <div class="item">
                <div class="inner-item">
                    <h3>SETZEN SIE SICH MIT IHREM
ENERGIEVERSORGER IN KONTAKT</h3>
                    <img src='assets/images/safe_food/e3.svg' />
                    <button class="modal-toggle18 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>ACHTEN SIE AUF
IHRE KÜHLGERÄTE</h3>
                    <img src="assets/images/safe_food/e4.svg" />
                  <button class="modal-toggle9 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                <h3>PRÜFEN SIE
IHREN KÜHLSCHRANK</h3>
                    <img src="assets/images/safe_food/e5.svg" />
                  <button class="modal-toggle8 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>VERSCHWENDEN SIE KEIN EIS</h3>
                    <img src="assets/images/safe_food/e6.svg" />
                  <button class="modal-toggle10 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>TAUSCHEN SIE IHRE GLÜHBIRNEN
GEGEN ENERGIEEFFIZIENTE
LEUCHTMITTEL AUS</h3>
                    <img src="assets/images/safe_food/e7.svg" />
                  <button class="modal-toggle12 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>REINIGEN UND PFLEGEN
SIE IHRE GERÄTE</h3>
                    <img src="assets/images/safe_food/e8.svg" />
                  <button class="modal-toggle13 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>SENKEN SIE IHREN WÄRMEBEDARF</h3>
                    <img src="assets/images/safe_food/e9.svg" />
                  <button class="modal-toggle14 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>ORGANISIEREN SIE IHRE KÜCHE NEU</h3>
                    <img src="assets/images/safe_food/e10.svg" />
                  <button class="modal-toggle15 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>SCHALTEN SIE NICHT BENÖTIGTE
LICHTER UND ELEKTRISCHE
GERÄTE AUS</h3>
                    <img src="assets/images/safe_food/e1.svg" />
                  <button class="modal-toggle16 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>LEGEN SIE EINEN AUSGANGSPUNKT
FEST UND ERSTELLEN SIE EINEN
KONKRETEN AKTIONSPLAN</h3>
                    <img src="assets/images/safe_food/e2.svg" />
                  <button class="modal-toggle17 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div>


              <!-- <div class="item">
                <div class="inner-item">
                    <h3>Responsible Sourcing</h3>
                    <img src="assets\images\the-msr-chapter\msr_10.png" />
                  <button class="modal-toggle18 read-more-btn">
                  WEITERLESEN
                  </button>
                </div>
              </div> -->


            </div>
          </div>

        </div>
      </section>

  <div class="eng-modal">
    <div class="modal-overlay1 modal-toggle8"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle8">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Prüfen Sie Ihren Kühlschrank</h4>
            <p>Wenn die Dichtungen Ihres Kühlschranks nicht sauber sind, besteht die Gefahr, dass warme Luft eindringt. Vergewissern Sie sich, dass die Ventilatoren Ihres Kühlschranks sowie die Kühl- und Lüftungsschlitze hinter freistehenden Kühl- und Gefriergeräten nicht blockiert sind.</p>

        </div>
      </div>
    </div>
  </div>

  <div class=" redu-modal">
    <div class="modal-overlay1 modal-toggle9"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle9">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Achten Sie auf Ihre Kühlgeräte</h4>
            <p>Es ist wichtig zu wissen, wie Ihre Kühlgeräte funktionieren. Beispielsweise sollten Sie darauf achten, wie viel Eis Sie maximal einfüllen können, damit die Belüftung nicht überlastet wird. Wenn der Luftstrom unterbrochen wird, verbraucht das Gerät mehr Energie, um die gleiche Menge Eis zu produzieren.</p>

        </div>
        
      </div>
    </div>
  </div>



  <div class=" set-modal">
    <div class="modal-overlay1 modal-toggle13"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle13">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Reinigen und pflegen Sie Ihre Geräte</h4>
            <p>Wenn Sie Ihre Geräte nicht reinigen und pflegen, verbrauchen sie mehr Energie als nötig. Nutzen Sie beispielsweise bei Geräten, die mit Wasser betrieben werden, ein Filtersystem, um zu verhindern, dass Ihre Geräte durch Kalk- und Mineralablagerungen beschädigt werden.</p>

</div>
      </div>
    </div>
  </div>


  <div class=" ver-modal">
    <div class="modal-overlay1 modal-toggle14"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle14">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Senken Sie Ihren Wärmebedarf</h4>
            <p>Verringern Sie Ihren Wärmebedarf, z. B. indem Sie die Wassertemperaturen senken. Beachten Sie jedoch die vorgeschriebenen Temperaturen für das Abwaschen von Geschirr. Sie können auch energieeffiziente Handtrockner ohne Heizelemente für Ihre Toiletten verwenden.
            </p>
        </div>
      </div>
    </div>
  </div>

  <div class=" exp-modal">
    <div class="modal-overlay1 modal-toggle15"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle15">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Organisieren Sie Ihre Küche neu</h4>
            <p>Organisieren Sie Ihre Küche so, dass wärmeerzeugende Geräte nicht in der Nähe von Kühlgeräten platziert werden. Achten Sie beispielsweise darauf, dass der Herd nicht neben der Eismaschine steht, damit nicht mehr Energie als nötig verwendet wird.
            </p>
        </div>
      </div>
    </div>
  </div>


  <div class=" neh-modal">
    <div class="modal-overlay1 modal-toggle16"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle16">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Schalten Sie nicht benötigte Lichter und elektrische Geräte aus</h4>
            <p>Sparen Sie Energie, indem Sie unnötige Lichter und elektrische Geräte ausschalten. Stellen Sie beispielsweise den Herd oder die Fritteuse bei Nichtnutzung aus und beginnen Sie erst dann mit dem Vorheizen, wenn Sie die Geräte benötigen. Auch Ihr Kassensystem und Ihre Computer sollten ausgeschaltet werden, wenn diese an Ruhetagen oder nachts nicht verwendet werden.</p>
       </div>
      </div>
    </div>
  </div>



  <div class=" setsie-modal">
    <div class="modal-overlay1 modal-toggle17"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle17">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">
        <div class="modal-content1 flexi-cont">
        <h4>Legen Sie einen Ausgangspunkt fest und erstellen Sie einen konkreten Aktionsplan</h4>
            <p>Bestimmen Sie einen Startpunkt, von dem aus Sie Verbesserungen vornehmen können. Dabei kann ein Rückblick auf Ihre Erfolge eine große Motivation sein! Erstellen Sie einen Maßnahmenplan mit realistischen Zielen für die Einsparung von Energie.</p>
       
        </div>
      </div>
    </div>
  </div>

  <div class="introdiv-modal">
    <div class="modal-overlay1 modal-toggle18"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle18">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Setzen Sie sich mit Ihrem Energieversorger in Kontakt</h4>
            <p>Wenden Sie sich an Ihren Energieversorger, um herauszufinden, wie viel Energie Sie monatlich verbrauchen. Prüfen Sie, zu welchem Zeitpunkt der höchste Verbrauch erreicht wird und werfen Sie einen Blick auf Ihre Rechnungen, um eine Vorstellung von den Kosten zu bekommen. Sie können auch einen Tracker einsetzen, um zu sehen, wie viel Energie Sie benötigen.</p>

        </div>
      </div>
    </div>
  </div>


  <div class=" intro-modal">
    <div class="modal-overlay1 modal-toggle10"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle10">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Verschwenden Sie kein Eis</h4>
            <p>Die Herstellung von Eis ist teuer und benötigt Wasser und Energie, also gehen Sie nicht verschwenderisch damit um. Füllen Sie nur so viel ein, wie Sie brauchen.</p>

</div>
      </div>
    </div>
  </div>
  <div class=" source-modal">
    <div class="modal-overlay1 modal-toggle11"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle11">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
          <h4>
            <a class="nodeco" href="introduction-to-responsible-sourcing-eng.php">Source locally, regionally and in season
</a>
          </h4>
          <p>Make an impact with responsible sourcing and only use responsibly sourced fish and food that is organic, nutritious, seasonal, ethically traded, local and regional. Moreover, try to buy foods that encourage biodiversity, do not involve waste and do not destroy forests. If you want to find out more, go to the responsible sourcing chapter. </p>
        </div>
      </div>
    </div>
  </div>

  <div class=" use-modal">
    <div class="modal-overlay1 modal-toggle12"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle12">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont more-text">
          <div>
          <h4>Tauschen Sie Ihre Glühbirnen gegen energieeffiziente Leuchtmittel aus</h4>
            <p>Energieeffiziente Leuchtmittel sind eine Möglichkeit, Energie zu sparen. Verwenden Sie LED-, Halogen- und Kompaktleuchtstofflampen für Ihre Küche und den Essbereich. Sie können auch Leuchten mit automatischem Lichtsensor und Bewegungsmelder installieren. Diese Art intelligenter Beleuchtung kann beispielsweise in Toiletten, Lager- oder Technikräumen eingesetzt werden.</p>
       

          </div>
        </div>
      </div>
    </div>


    <script>
      var x, i, j, l, ll, selElmnt, a, b, c;
      /*look for any elements with the class "custom-select":*/
      x = document.getElementsByClassName("custom-select");
      l = x.length;
      for (i = 0; i < l; i++) {
        selElmnt = x[i].getElementsByTagName("select")[0];
        ll = selElmnt.length;
        /*for each element, create a new DIV that will act as the selected item:*/
        a = document.createElement("DIV");
        a.setAttribute("class", "select-selected");
        a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
        x[i].appendChild(a);
        /*for each element, create a new DIV that will contain the option list:*/
        b = document.createElement("DIV");
        b.setAttribute("class", "select-items select-hide");
        for (j = 1; j < ll; j++) {
          /*for each option in the original select element,
          create a new DIV that will act as an option item:*/
          c = document.createElement("DIV");
          c.innerHTML = selElmnt.options[j].innerHTML;
          c.addEventListener("click", function(e) {
            /*when an item is clicked, update the original select box,
            and the selected item:*/
            var y, i, k, s, h, sl, yl;
            s = this.parentNode.parentNode.getElementsByTagName("select")[0];
            sl = s.length;
            h = this.parentNode.previousSibling;
            for (i = 0; i < sl; i++) {
              if (s.options[i].innerHTML == this.innerHTML) {
                s.selectedIndex = i;
                h.innerHTML = this.innerHTML;
                y = this.parentNode.getElementsByClassName("same-as-selected");
                yl = y.length;
                for (k = 0; k < yl; k++) {
                  y[k].removeAttribute("class");
                }
                this.setAttribute("class", "same-as-selected");
                break;
              }
            }
            h.click();
          });
          b.appendChild(c);
        }
        x[i].appendChild(b);
        a.addEventListener("click", function(e) {
          /*when the select box is clicked, close any other select boxes,
          and open/close the current select box:*/
          e.stopPropagation();
          closeAllSelect(this);
          this.nextSibling.classList.toggle("select-hide");
          this.classList.toggle("select-arrow-active");
        });
      }

      function closeAllSelect(elmnt) {
        /*a function that will close all select boxes in the document,
        except the current select box:*/
        var x, y, i, xl, yl, arrNo = [];
        x = document.getElementsByClassName("select-items");
        y = document.getElementsByClassName("select-selected");
        xl = x.length;
        yl = y.length;
        for (i = 0; i < yl; i++) {
          if (elmnt == y[i]) {
            arrNo.push(i)
          } else {
            y[i].classList.remove("select-arrow-active");
          }
        }
        for (i = 0; i < xl; i++) {
          if (arrNo.indexOf(i)) {
            x[i].classList.add("select-hide");
          }
        }
      }
      /*if the user clicks anywhere outside the select box,
      then close all select boxes:*/
      document.addEventListener("click", closeAllSelect);



      $('.slider').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        arrows: true,
        dots: false,
        centerMode: true,
        variableWidth: true,
        infinite: true,
        focusOnSelect: true,
        cssEase: 'linear',
        touchMove: true,
        prevArrow: '<button class="slick-prev"> < </button>',
        nextArrow: '<button class="slick-next"> > </button>',

        //         responsive: [                        
        //             {
        //               breakpoint: 576,
        //               settings: {
        //                 centerMode: false,
        //                 variableWidth: false,
        //               }
        //             },
        //         ]
      });



      var imgs = $('.slider img');
      imgs.each(function() {
        var item = $(this).closest('.item');
        item.css({
          'background-image': 'url(' + $(this).attr('src') + ')',
          'background-position': 'center',
          '-webkit-background-size': 'cover',
          'background-size': 'cover',
        });
        $(this).hide();
      });

      $('.slider2').slick({
        slidesToShow: 3,
        arrows: true,
        dots: false,
        centerMode: true,
        variableWidth: true,
        infinite: true,
        focusOnSelect: true,
        cssEase: 'linear',
        touchMove: true,
        prevArrow: '<button class="slick-prev"> < </button>',
        nextArrow: '<button class="slick-next"> > </button>',

        //         responsive: [                        
        //             {
        //               breakpoint: 576,
        //               settings: {
        //                 centerMode: false,
        //                 variableWidth: false,
        //               }
        //             },
        //         ]
      });

      var imgs = $('.slider2 img');
      imgs.each(function() {
        var item = $(this).closest('.item');
        item.css({
          'background-image': 'url(' + $(this).attr('src') + ')',
          'background-position': 'center',
          '-webkit-background-size': 'cover',
          'background-size': 'cover',
        });
        $(this).hide();
      });




      let collapsibleHeaders = document.getElementsByClassName('collapsible__header');

      Array.from(collapsibleHeaders).forEach(header => {
        header.addEventListener('click', () => {
          header.parentElement.classList.toggle('collapsible--open');
        });
      });

      // Quick & dirty toggle to demonstrate modal toggle behavior
      $('.modal-toggle1').on('click', function(e) {
        e.preventDefault();
        $('.vegan-modal').toggleClass('is-visible');
      });
      $('.modal-toggle2').on('click', function(e) {
        e.preventDefault();
        $('.vegi-modal').toggleClass('is-visible');
      });
      $('.modal-toggle3').on('click', function(e) {
        e.preventDefault();
        $('.paleo-modal').toggleClass('is-visible');
      });
      $(' .modal-toggle4').on('click', function(e) {
        e.preventDefault();
        $('.keto-modal').toggleClass('is-visible');
      });
      $('.modal-toggle5').on('click', function(e) {
        e.preventDefault();
        $('.fruit-modal').toggleClass('is-visible');
      });
      $('.modal-toggle6').on('click', function(e) {
        e.preventDefault();
        $('.omni-modal').toggleClass('is-visible');
      });
      $('.modal-toggle7').on('click', function(e) {
        e.preventDefault();
        $('.flexi-modal').toggleClass('is-visible');
      });
      $('.modal-toggle8').on('click', function(e) {
        e.preventDefault();
        $('.eng-modal').toggleClass('is-visible');
      });
      $('.modal-toggle9').on('click', function(e) {
        e.preventDefault();
        $('.redu-modal').toggleClass('is-visible');
      });
      $('.modal-toggle10').on('click', function(e) {
        e.preventDefault();
        $('.intro-modal').toggleClass('is-visible');
      });
      $('.modal-toggle11').on('click', function(e) {
        e.preventDefault();
        $('.source-modal').toggleClass('is-visible');
      });
      $('.modal-toggle12').on('click', function(e) {
        e.preventDefault();
        $('.use-modal').toggleClass('is-visible');
      });

      $('.modal-toggle13').on('click', function(e) {
        e.preventDefault();
        $('.set-modal').toggleClass('is-visible');
      });
      $('.modal-toggle14').on('click', function(e) {
        e.preventDefault();
        $('.ver-modal').toggleClass('is-visible');
      });
      $('.modal-toggle15').on('click', function(e) {
        e.preventDefault();
        $('.exp-modal').toggleClass('is-visible');
      });
      $('.modal-toggle16').on('click', function(e) {
        e.preventDefault();
        $('.neh-modal').toggleClass('is-visible');
      });
      $('.modal-toggle17').on('click', function(e) {
        e.preventDefault();
        $('.setsie-modal').toggleClass('is-visible');
      });

      $('.modal-toggle18').on('click', function(e) {
        e.preventDefault();
        $('.introdiv-modal').toggleClass('is-visible');
      });
    </script>


   