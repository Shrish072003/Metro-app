<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="stylesheet" href="../../assets/prev/css/page2_style.css">
  <script src="https://code.jquery.com/jquery-2.2.4.js"></script>
  <script src="../../assets/prev/jquery/custom.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
  <link rel="stylesheet" href="../../assets/css/navigation.css">
  <link href="../../assets/css/normalize.min.css" rel="stylesheet">
  <link href="../../assets/css/style1.css" rel="stylesheet">
  <link href="../../assets/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">

  <link rel="apple-touch-icon" sizes="180x180" href="../../assets/images/icon-180x180.png">
  <link rel="icon" type="image/png" sizes="32x32" href="../../assets/images/icon-32x32.png">
  <link rel="mask-icon" href="../..//safari-pinned-tab.svg" color="#5bbad5">
  <link rel="stylesheet" href="../../assets\css\responsive.css">
  <link rel="stylesheet" href="slider.css">
  <!--META TAGS-->
  <meta name="msapplication-TileColor" content="#603cba">
  <meta name="theme-color" content="#ffffff">
  <meta name="robots" content="noindex,nofollow">
  <style>
    .section-lena-inner {
      padding-left: 0;
    }

    body {
      overflow: auto;
      
    }

    nav.navbar {
      height: 60px;
      top: 0;
    }

    .c9 {
      padding-left: 0 !important;
      padding-right: 0 !important;
      max-width: 100%;
    }

    .likebtn {
      margin-bottom: 2rem;
    }

    .spacerx {
      margin-top: 3rem;
    }

    .nodeco {
      color: white !important;
      text-decoration: none !important;
    }

    .nowrap1 {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    @media print {
      body * {
        visibility: hidden;
      }

      .section-to-print,
      .section-to-print * {
        visibility: visible;
      }

      .section-to-print {
        position: absolute;
        left: 0;
        top: 0;
      }
    }

    .section1 {
      background-color: white;
    }

    .w100p {
      width: 100% !important;
      max-width: 100% !important;
    }

    .mid-highlight.container {
      max-width: 100%;
    }

    .section-lena-kitchen {
      max-width: 100%;
    }

    .section-simple-way {
      background-color: white;
    }

    .page-3_stage.page-4_stage {
      background-color: white;
    }
    .item.slick-slide {
    width: 280px;
    height: 450px !important;
    transition: transform 0.4s;
    position: relative;
}
.custom__select:before{
            background:#ffe500;
        }
        nav.navbar {
      height: 60px;
      top: 0;
    }
        .search-btn{    margin-right: 0px;
     }
     .custom__select:before {
    right: 5px !important;
    top: 3px;
}
.custom__select select {
    color: #ffe500;
    padding-left: 4px;
}
.slick-slide img {
    display: block !important;
    width: auto;
    max-height: 150px !important;
    object-fit: contain !important;
}
.section-slider2 .inner-item button {
    padding-top: 0;
    display: table;
    margin-right: auto;
    margin-left: auto;
    border-radius: 50px;
}
.section-slider1 {
    margin-top: auto;
}
.footer-wrap {
    position: relative !important;
}
.inner-item {
    background-color: #ffffff;
    background-image: none !important;
}
.section-slider2 .slick-slide:after {
    background: none !important;
    background-color: #DDDDDD !important;
}
.wrap {
    background: transparent !important;
}
.inner-item button {
    background-color: #003b7e !important;
    height: 40px !important;
    font-size: 18px !important;
    width: 160px;
    color: #fff !important;
    padding-top: 10px !important;
}
.section-slider-center h3, .top-content h3 {
    font-size: 40px;
    padding: 0px 0 10px !important;
}
.modal-content1 img{
    margin-bottom: 20px;
}
.modal-content1 .read-more-btn{
    background-color: #ffe500 !important;
    margin-right: auto;
    margin-left: auto;
    font-size: 18px;
    color: #fff;
}
.slick-slide{
  background-image:none !important;
}
.modal-wrapper1 {
    height: 70% !important;
}
.slider2 .item.slick-slide {
    width: 250px !important;
}
.section-slider-center h3 {
    text-transform: capitalize;
    font-size: 20px !important;
}
/* .simple_wayTo_preventing .container-fluid .text-center img {
    width: 80% !important;
    margin-top: 0.5rem !important;
    display: table !important;
    margin-right: auto;
    margin-left: auto;
} */
.social_slde span.slimg-holder {
    top: 0rem !important;
}
span.slimg-holder.socils_one {
    padding: 6px 24px;
}
/* .section-slider1 {
        border-top: 1px solid #fff;
        background: none !important;
        margin-bottom: 50px;
    } */

    .inner-item button {
    width: 180px !important;
}
h3{
    overflow-wrap: break-word;
}
  </style>
<section class="section-slider1 section-slider2 no-print">

        <div class="section-slider-center text-center">
          <div class="wrap" style="z-index: 0;">
            <div class="slider2">
              <div class="item">
                <div class="inner-item">
                    <h3>Sortieren Sie Ihren Abfall und versuchen Sie, ihn nach Arten zu trennen (Lebensmittel, Plastik, Karton usw.)</h3>
                    <img src='assets/images/safe_food/wl8.svg' />
                    <!-- <button class="modal-toggle24 read-more-btn">
                  Read more
                  </button> -->
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>Ermitteln Sie die Abfallquellen und sprechen Sie mit Ihren Mitarbeitenden über deren Ideen zur Abfallverringerung</h3>
                    <img src='assets/images/safe_food/wl9.svg' />
                  <!-- <button class="modal-toggle9 read-more-btn">
                  Read more
                  </button> -->
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                <h3>Vergewissern Sie sich,
dass Ihr bestehendes Abfallmanagementsystem richtig genutzt wird</h3>
                <img src='assets/images/safe_food/wl10.svg' />
                  <!-- <button class="modal-toggle8 read-more-btn">
                  Read more
                  </button> -->
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>Wenden Sie sich an Ihre Behörden vor Ort, um zu erfahren, welche Lösungen es gibt</h3>
                    <img src='assets/images/safe_food/wl11.svg' />
                  <!-- <button class="modal-toggle10 read-more-btn">
                  Read more
                  </button> -->
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>Für die Entsorgung von Lebensmittelabfällen finden Sie hier einige Tipps</h3>
                    <img src='assets/images/safe_food/wl12.svg' />
                    <a href="introduction-to-food-waste-deu.php" target="_blank"><button class="read-more-btn">
                    WEITERLESEN
                  </button></a>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>Für Einwegartikel aus Kunststoff, z. B. Produkte zum Mitnehmen, Plastikrührstäbchen und Verpackungen aus Kunststoff, schauen Sie sich diese Hinweise an</h3>
                    <img src='assets/images/safe_food/wl13.svg' style="max-height: 50px !important;"/>
                    <a href="introduction-to-plastic-waste-deu.php" target="_blank"><button class="read-more-btn" >
                    WEITERLESEN
                  </button></a>
                </div>
              </div>

              


            </div>
          </div>

        </div>
      </section>

    <script>
      var x, i, j, l, ll, selElmnt, a, b, c;
      /*look for any elements with the class "custom-select":*/
      x = document.getElementsByClassName("custom-select");
      l = x.length;
      for (i = 0; i < l; i++) {
        selElmnt = x[i].getElementsByTagName("select")[0];
        ll = selElmnt.length;
        /*for each element, create a new DIV that will act as the selected item:*/
        a = document.createElement("DIV");
        a.setAttribute("class", "select-selected");
        a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
        x[i].appendChild(a);
        /*for each element, create a new DIV that will contain the option list:*/
        b = document.createElement("DIV");
        b.setAttribute("class", "select-items select-hide");
        for (j = 1; j < ll; j++) {
          /*for each option in the original select element,
          create a new DIV that will act as an option item:*/
          c = document.createElement("DIV");
          c.innerHTML = selElmnt.options[j].innerHTML;
          c.addEventListener("click", function(e) {
            /*when an item is clicked, update the original select box,
            and the selected item:*/
            var y, i, k, s, h, sl, yl;
            s = this.parentNode.parentNode.getElementsByTagName("select")[0];
            sl = s.length;
            h = this.parentNode.previousSibling;
            for (i = 0; i < sl; i++) {
              if (s.options[i].innerHTML == this.innerHTML) {
                s.selectedIndex = i;
                h.innerHTML = this.innerHTML;
                y = this.parentNode.getElementsByClassName("same-as-selected");
                yl = y.length;
                for (k = 0; k < yl; k++) {
                  y[k].removeAttribute("class");
                }
                this.setAttribute("class", "same-as-selected");
                break;
              }
            }
            h.click();
          });
          b.appendChild(c);
        }
        x[i].appendChild(b);
        a.addEventListener("click", function(e) {
          /*when the select box is clicked, close any other select boxes,
          and open/close the current select box:*/
          e.stopPropagation();
          closeAllSelect(this);
          this.nextSibling.classList.toggle("select-hide");
          this.classList.toggle("select-arrow-active");
        });
      }

      function closeAllSelect(elmnt) {
        /*a function that will close all select boxes in the document,
        except the current select box:*/
        var x, y, i, xl, yl, arrNo = [];
        x = document.getElementsByClassName("select-items");
        y = document.getElementsByClassName("select-selected");
        xl = x.length;
        yl = y.length;
        for (i = 0; i < yl; i++) {
          if (elmnt == y[i]) {
            arrNo.push(i)
          } else {
            y[i].classList.remove("select-arrow-active");
          }
        }
        for (i = 0; i < xl; i++) {
          if (arrNo.indexOf(i)) {
            x[i].classList.add("select-hide");
          }
        }
      }
      /*if the user clicks anywhere outside the select box,
      then close all select boxes:*/
      document.addEventListener("click", closeAllSelect);



      $('.slider').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        arrows: true,
        dots: false,
        centerMode: true,
        variableWidth: true,
        infinite: true,
        focusOnSelect: true,
        cssEase: 'linear',
        touchMove: true,
        prevArrow: '<button class="slick-prev"> < </button>',
        nextArrow: '<button class="slick-next"> > </button>',

        //         responsive: [                        
        //             {
        //               breakpoint: 576,
        //               settings: {
        //                 centerMode: false,
        //                 variableWidth: false,
        //               }
        //             },
        //         ]
      });



      var imgs = $('.slider img');
      imgs.each(function() {
        var item = $(this).closest('.item');
        item.css({
          'background-image': 'url(' + $(this).attr('src') + ')',
          'background-position': 'center',
          '-webkit-background-size': 'cover',
          'background-size': 'cover',
        });
        $(this).hide();
      });

      $('.slider2').slick({
        slidesToShow: 3,
        arrows: true,
        dots: false,
        centerMode: true,
        variableWidth: true,
        infinite: true,
        focusOnSelect: true,
        cssEase: 'linear',
        touchMove: true,
        prevArrow: '<button class="slick-prev"> < </button>',
        nextArrow: '<button class="slick-next"> > </button>',

        //         responsive: [                        
        //             {
        //               breakpoint: 576,
        //               settings: {
        //                 centerMode: false,
        //                 variableWidth: false,
        //               }
        //             },
        //         ]
      });

      var imgs = $('.slider2 img');
      imgs.each(function() {
        var item = $(this).closest('.item');
        item.css({
          'background-image': 'url(' + $(this).attr('src') + ')',
          'background-position': 'center',
          '-webkit-background-size': 'cover',
          'background-size': 'cover',
        });
        $(this).hide();
      });




      let collapsibleHeaders = document.getElementsByClassName('collapsible__header');

      Array.from(collapsibleHeaders).forEach(header => {
        header.addEventListener('click', () => {
          header.parentElement.classList.toggle('collapsible--open');
        });
      });

      // Quick & dirty toggle to demonstrate modal toggle behavior
      $('.modal-toggle1').on('click', function(e) {
        e.preventDefault();
        $('.vegan-modal').toggleClass('is-visible');
      });
      $('.modal-toggle2').on('click', function(e) {
        e.preventDefault();
        $('.vegi-modal').toggleClass('is-visible');
      });
      $('.modal-toggle3').on('click', function(e) {
        e.preventDefault();
        $('.paleo-modal').toggleClass('is-visible');
      });
      $(' .modal-toggle4').on('click', function(e) {
        e.preventDefault();
        $('.keto-modal').toggleClass('is-visible');
      });
      $('.modal-toggle5').on('click', function(e) {
        e.preventDefault();
        $('.fruit-modal').toggleClass('is-visible');
      });
      $('.modal-toggle6').on('click', function(e) {
        e.preventDefault();
        $('.omni-modal').toggleClass('is-visible');
      });
      $('.modal-toggle7').on('click', function(e) {
        e.preventDefault();
        $('.flexi-modal').toggleClass('is-visible');
      });
      $('.modal-toggle8').on('click', function(e) {
        e.preventDefault();
        $('.eng-modal').toggleClass('is-visible');
      });
      $('.modal-toggle9').on('click', function(e) {
        e.preventDefault();
        $('.redu-modal').toggleClass('is-visible');
      });
      $('.modal-toggle10').on('click', function(e) {
        e.preventDefault();
        $('.intro-modal').toggleClass('is-visible');
      });
      $('.modal-toggle11').on('click', function(e) {
        e.preventDefault();
        $('.source-modal').toggleClass('is-visible');
      });
      $('.modal-toggle12').on('click', function(e) {
        e.preventDefault();
        $('.use-modal').toggleClass('is-visible');
      });

      $('.modal-toggle13').on('click', function(e) {
        e.preventDefault();
        $('.set-modal').toggleClass('is-visible');
      });
      $('.modal-toggle14').on('click', function(e) {
        e.preventDefault();
        $('.ver-modal').toggleClass('is-visible');
      });
      $('.modal-toggle15').on('click', function(e) {
        e.preventDefault();
        $('.exp-modal').toggleClass('is-visible');
      });
      $('.modal-toggle16').on('click', function(e) {
        e.preventDefault();
        $('.neh-modal').toggleClass('is-visible');
      });
      $('.modal-toggle17').on('click', function(e) {
        e.preventDefault();
        $('.setsie-modal').toggleClass('is-visible');
      });

      $('.modal-toggle18').on('click', function(e) {
        e.preventDefault();
        $('.introdiv-modal18').toggleClass('is-visible');
      });
      $('.modal-toggle19').on('click', function(e) {
        e.preventDefault();
        $('.introdiv-modal19').toggleClass('is-visible');
      });
      $('.modal-toggle20').on('click', function(e) {
        e.preventDefault();
        $('.introdiv-modal20').toggleClass('is-visible');
      });
      $('.modal-toggle21').on('click', function(e) {
        e.preventDefault();
        $('.introdiv-modal21').toggleClass('is-visible');
      });
      $('.modal-toggle22').on('click', function(e) {
        e.preventDefault();
        $('.introdiv-modal22').toggleClass('is-visible');
      });
      $('.modal-toggle23').on('click', function(e) {
        e.preventDefault();
        $('.introdiv-modal23').toggleClass('is-visible');
      });
      $('.modal-toggle24').on('click', function(e) {
        e.preventDefault();
        $('.introdiv-modal24').toggleClass('is-visible');
      });


    </script>
