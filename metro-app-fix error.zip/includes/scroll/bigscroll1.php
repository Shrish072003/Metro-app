<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="stylesheet" href="../../assets/prev/css/page2_style.css">
  <script src="https://code.jquery.com/jquery-2.2.4.js"></script>
  <script src="../../assets/prev/jquery/custom.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
  <link rel="stylesheet" href="../../assets/css/navigation.css">
  <link href="../../assets/css/normalize.min.css" rel="stylesheet">
  <link href="../../assets/css/style1.css" rel="stylesheet">
  <link href="../../assets/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">

  <link rel="apple-touch-icon" sizes="180x180" href="../../assets/images/icon-180x180.png">
  <link rel="icon" type="image/png" sizes="32x32" href="../../assets/images/icon-32x32.png">
  <link rel="mask-icon" href="../..//safari-pinned-tab.svg" color="#5bbad5">
  <link rel="stylesheet" href="../../assets\css\responsive.css">
  <link rel="stylesheet" href="slider.css">
  <!--META TAGS-->
  <meta name="msapplication-TileColor" content="#603cba">
  <meta name="theme-color" content="#ffffff">
  <meta name="robots" content="noindex,nofollow">
  <style>
    .section-lena-inner {
      padding-left: 0;
    }

    body {
      overflow: auto;
    }

    nav.navbar {
      height: 60px;
      top: 0;
    }

    .c9 {
      padding-left: 0 !important;
      padding-right: 0 !important;
      max-width: 100%;
    }

    .likebtn {
      margin-bottom: 2rem;
    }

    .spacerx {
      margin-top: 3rem;
    }

    .nodeco {
      color: white !important;
      text-decoration: none !important;
    }

    .nowrap1 {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    @media print {
      body * {
        visibility: hidden;
      }

      .section-to-print,
      .section-to-print * {
        visibility: visible;
      }

      .section-to-print {
        position: absolute;
        left: 0;
        top: 0;
      }
    }

    .section1 {
      margin-top: 4rem;
      background-color: white;
    }

    .w100p {
      width: 100% !important;
      max-width: 100% !important;
    }

    .mid-highlight.container {
      max-width: 100%;
    }

    .section-lena-kitchen {
      max-width: 100%;
    }

    .section-simple-way {
      background-color: white;
    }

    .page-3_stage.page-4_stage {
      background-color: white;
    }
    .item.slick-slide {
    width: 280px;
    height: 450px !important;
    transition: transform 0.4s;
    position: relative;
}
.custom__select:before{
            background:#ffe500;
        }
        nav.navbar {
      height: 60px;
      top: 0;
    }
        .search-btn{    margin-right: 0px;
     }
     .custom__select:before {
    right: 5px !important;
    top: 3px;
}
.custom__select select {
    color: #ffe500;
    padding-left: 4px;
}
.slick-slide img {
    display: block !important;
    width: auto;
    max-height: 250px !important;
    object-fit: contain !important;

}
.section-slider1 {
    margin-top: auto;
}
.footer-wrap {
    position: relative !important;
}
.inner-item {
    background-color: #ffffff;
    background-image: none !important;
}
.section-slider2 .slick-slide:after {
    background: none !important;
    background-color: #DDDDDD !important;
}
.wrap {
    background: transparent !important;
    margin-bottom: 100px;
}
.inner-item button {
    background-color: #003b7e !important;
    height: 40px !important;
    font-size: 18px !important;
    width: 160px;
    color: #fff !important;
    padding-top: 10px !important;
}
.section-slider-center h3, .top-content h3 {
    font-size: 32px;
    padding: 0px 0 10px !important;
}
.modal-content1 img{
    margin-bottom: 20px;
}
.modal-content1 .read-more-btn{
    background-color: #ffe500 !important;
    margin-right: auto;
    margin-left: auto;
    font-size: 18px;
    color: #fff;
}
.slick-slide{
  background-image:none !important;
}
.modal-wrapper1 {
    height: 70% !important;
}
  </style>
<section class="section-slider1 section-slider2 no-print">
        <div class="section-slider-center text-center">
          <div class="wrap" style="z-index: 0;">
            <div class="slider2">
              <div class="item">
                <div class="inner-item">
                    <h3>Identify different types of waste</h3>
                    <img src='assets/images/safe_food/fw-2.svg?width="54px"%20height="54px"' />
                    <button class="modal-toggle15 read-more-btn">
                  Read more
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>Store fruits and vegetables. IN THE RIGHT WAY</h3>
                    <img src="assets/images/safe_food/fw-3.svg" />
                  <button class="modal-toggle9 read-more-btn">
                  Read more
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                <h3>Only order what you really need</h3>
                    <img src="assets/images/safe_food/fw-4.svg" />
                  <button class="modal-toggle8 read-more-btn">
                  Read more
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>Source rightfully</h3>
                    <img src="assets/images/safe_food/fw-5.svg" />
                  <button class="modal-toggle10 read-more-btn">
                  Read more
                  </button>
                </div>
              </div>
              <div class="item">
                <div class="inner-item">
                    <h3>Compost the Scraps</h3>
                    <img src="assets/images/safe_food/fw-6.svg" />
                  <button class="modal-toggle12 read-more-btn">
                  Read more
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>Discount or donate surplus food</h3>
                    <img src="assets/images/safe_food/fw-7.svg" />
                  <button class="modal-toggle13 read-more-btn">
                  Read more
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>Engage your staff</h3>
                    <img src="assets/images/safe_food/fw-1.svg" />
                  <button class="modal-toggle14 read-more-btn">
                  Read more
                  </button>
                </div>
              </div>
<!-- 
              <div class="item">
                <div class="inner-item">
                    <h3>Sustainable Menu</h3>
                    <img src="assets\images\the-msr-chapter\msr_7.png" />
                  <button class="modal-toggle15 read-more-btn">
                  Read more
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>Social</h3>
                    <img src="assets\images\the-msr-chapter\msr_8.png" />
                  <button class="modal-toggle16 read-more-btn">
                  Read more
                  </button>
                </div>
              </div>

              <div class="item">
                <div class="inner-item">
                    <h3>Water</h3>
                    <img src="assets\images\the-msr-chapter\msr_9.png" />
                  <button class="modal-toggle17 read-more-btn">
                  Read more
                  </button>
                </div>
              </div> -->


              <!-- <div class="item">
                <div class="inner-item">
                    <h3>Responsible Sourcing</h3>
                    <img src="assets\images\the-msr-chapter\msr_10.png" />
                  <button class="modal-toggle18 read-more-btn">
                  Read more
                  </button>
                </div>
              </div> -->


            </div>
          </div>

        </div>
      </section>

  <div class="eng-modal">
    <div class="modal-overlay1 modal-toggle8"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle8">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4> Only order what you really need</h4>
                <p>Avoid food waste in the first place. Only order food that you will really consume. </p>
        </div>
      </div>
    </div>
  </div>

  <div class=" redu-modal">
    <div class="modal-overlay1 modal-toggle9"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle9">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4> Store fruits and vegetables in the right way </h4>
                <p> Fruit and vegetables are a major contributor to the amount of food waste in a restaurant. Check whether you already make use of all possible ways to store fruit and vegetables well, in order to prevent food waste:

                <ul>
                    <li>Ensure your storage area is well ventilated</li>
                    <li>Use the First-In-First-Out (FIFO) principle to ensure that products that come in first, go out first</li>
                    <li>Store fruit and vegetables at a lower temperature than their normal growing environment to preserve them longer</li>
                    <li>Store fruits and vegetables according to their specific storage temperatures. Berries can be stored in a cold fridge but bananas are stored best of the fridge in a cool place. </li>
                    <li>Leave fresh produce out of their temperature zones for as short as possible. For example, packaged salads may lose a day’s shelf life for every hour that their kept out of their optimum temperature range</li>
                    <li>Handle fruits and vegetables carefully to avoid damage</li>
                    <li>Stack light weight boxes of delicate items such as berries and mushrooms on top</li>
                    <li>Take care of pre-packaged produce, for example, apples in a plastic bag because the damage of one product can easily and quickly damage the others</li>
                    <li>If you have space try to separate ethylene-producing products (bananas, apple, pear, kiwi, fig, melon, and tomatoes) from ethylene-sensitive products (citrus, pineapple, leafy vegetables, cherries, berries, grapes, and most fruit vegetables (avocado, banana, cucumber, eggplant and tomatoes). This segregation will slow down the ripening of the ethylene-sensitive products</li>
                </ul>
                </p>
        </div>
        
      </div>
    </div>
  </div>



  <div class=" set-modal">
    <div class="modal-overlay1 modal-toggle13"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle13">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4> Discount or donate surplus food </h4>
                <p>Surplus food doesn’t have to be wasted. By donating or discounting your surplus food (e.g. <a href="https://toogoodtogo.org/" target="_blank">TOO GOOD TO GO</a>, Whole Surplus, or <a href="https://sirplus.de/" target="_blank"> Sirplus</a>), you prevent that food from ending up in a landfill while also helping people in need. Moreover, donations boost your employees’ morale as they see that they are having a positive impact and, depending on your locality, this may bring you financial advantages due to tax benefits of food donations. Food can be donated to charity organizations, food banks, zoos and animal shelters. Usually, food banks will have some requirements about what they accept, for example:
                <ul>
                    <li>Fresh packaged food that is in date</li>
                    <li>Fruits and vegetables that are not rotten</li>
                    <li>Unopened food</li>
                </ul>

                </p></div>
      </div>
    </div>
  </div>


  <div class=" ver-modal">
    <div class="modal-overlay1 modal-toggle14"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle14">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Engage your staff</h4>
                <p> When you try to avoid food waste, you should talk with your staff and help them understand the importance of eliminating the waste. Your staff’s engagement is crucial to making all the investments work. Keeping them up to date and training them will be needed. You can do this simply by implementing daily briefings, placing posters in easy-to-see places, or reminding them that each one of them is needed to fight food waste. </p>

        </div>
      </div>
    </div>
  </div>

  <div class=" exp-modal">
    <div class="modal-overlay1 modal-toggle15"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle15">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4>Identifying different types of waste</h4>
                <p> Food waste may be all around but you can take simple steps to reduce it. Start by identifying different types of waste in your restaurant and where it is generated. Generally, food waste comes from either the back of the house (e.g. the store room and the kitchen) or from the front of the house (e.g. where customers are served). Check how much food waste your restaurant generates and observe where most food waste is coming from.
                </p>
                <div class="row mt-4">
                    <div class="col-md-6">
                        <h6><strong>Back of house food waste</strong></h6>
                        <ul>
                            <li> Measure, track and analyse the food wasted</li>
                            <li> Evaluate your inventory, menu and dish sales. Remove non-sellers from the menu</li>
                            <li> Use digital tools such as <a href="https://www.menukithd.com/" target="_blank">Menukit</a> to track recipes and calculate the daily food needed in order to control your purchasing cost</li>
                            <li> Ask your staff to “hunt” for waste and suggest ways to manage it</li>
                            <li> Optimize the shelf life by ensuring that the cool chain is not broken and products are stored at the right temperature </li>
                            <li> Organise and label your stock so that the shelf life is visible and you can more easily rotate it</li>
                            <li> Ensure all opened and prepared ingredients have a label stating the shelf life</li>
                            <li> Keep your stock organized so that you know what needs to be used up and to ensure you don’t order more than your kitchen needs</li>
                            <li>Check your inventory frequently in order to compare purchased quantities and the quantity of food wasted</li>
                            <li>Find ways of repurposing unused ingredients and parts of food with <a href="https://www.mpulse.de/en/gastronomy/food-trends-for-the-hospitality-industry" target="_blank"> zero waste</a> recipes</li>
                            <li> Consider that food scraps (not of animal origin) can be donated for animal feed in a local animal shelter or a zoo</li>
                            <li> At the end of the service, allow your staff to eat the surplus food or take it home</li>
                            <li>Donate your surplus ingredients if you can´t use them</li>
                            <li> Recycle and / or upcycle waste where possible</li>
                            <li>Learn to <a href="https://www.mpulse.de/en/movinggoods/nose-to-tail-vergessene-delicatessen" target="_blank"> cook with unwanted parts</a> of meat, fish, fruit and vegetables</li>


                        </ul>
                    </div>
                  
                    <div class="col-md-6">
                    <br><br>
                        <h6><strong>Front of house food waste</strong></h6>
                        <ul>
                            <li> Monitor portion sizes to check if you should change the quantity depending how much food waste you have per customer </li>
                            <li> Think about using smaller plates</li>
                            <li> Track the popularity of each dish </li>
                            <li> Encourage guests to take their leftover food with them</li>
                            <li> Make the portion sizes clear and ensure your staff gives a realistic idea to your guests about the sizes</li>
                            <li> Update your menu in order to minimize the quantity of leftovers</li>
                            <li> Discount your surplus food</li>
                            <li> Donate your surplus food if you can’t resell it</li>
                            <li> Sort your food waste properly so that it goes to the correct stream for processing</li>
                            <li> Consider composting where possible </li>
                            <li> Tell your customers about your actions and publicise them in your community</li>

                        </ul>
                    </div>
                </div>
        </div>
      </div>
    </div>
  </div>


  <div class=" neh-modal">
    <div class="modal-overlay1 modal-toggle16"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle16">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
          <h4>Why gastronomy must engage socially </h4>
          <img src="assets/prev/images/L2-09.svg" />
          <p>When your staff is treated well, the positive effects on your business are felt not only in your restaurant but also in the community around you. As a restaurant owner, you have direct responsibility for your employees, but you also have indirect responsibility for every worker in the supply chain - the community overall. Take an active role in your community and ensure the welfare of your employees, your customers, your suppliers, and others in society whom you are in touch with.</p>
          <button class="read-more-btn" href="introduction-to-social-eng.php">
        TAKE A DEEP DIVE 
                  </button></div>
      </div>
    </div>
  </div>



  <div class=" setsie-modal">
    <div class="modal-overlay1 modal-toggle17"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle17">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">
        <div class="modal-content1 flexi-cont">
          <h4>How to save water in your restaurant</h4>
          <img src="assets/prev/images/L2-01.svg" />
          <p>Water runs your business. As a restaurant owner, you require a large amount of it before, during and after the service, from cooking and steaming to washing and sanitizing. But water does not only cost you money, it is also precious. Show your customers that you take responsibility and adapt water saving behavior with long-term benefits for you and the environment. </p>
          <button class="read-more-btn" href="introduction-to-water-eng.php">
        TAKE A DEEP DIVE 
                  </button>
        </div>
      </div>
    </div>
  </div>

  <div class="introdiv-modal">
    <div class="modal-overlay1 modal-toggle18"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle18">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
          <h4>
            Introduce diverse grains
          </h4>
          <p>Use ancient varieties of grains such as teff or those that are common to your region.
          </p>
        </div>
      </div>
    </div>
  </div>


  <div class=" intro-modal">
    <div class="modal-overlay1 modal-toggle10"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle10">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
        <h4> Source rightfully </h4>
                <p>Embrace produce imperfections, but steer clear of vegetables or fruits that are overly bruised or damaged.</p></div>
      </div>
    </div>
  </div>
  <div class=" source-modal">
    <div class="modal-overlay1 modal-toggle11"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle11">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont">
          <h4>
            <a class="nodeco" href="introduction-to-responsible-sourcing-eng.php">Source locally, regionally and in season
</a>
          </h4>
          <p>Make an impact with responsible sourcing and only use responsibly sourced fish and food that is organic, nutritious, seasonal, ethically traded, local and regional. Moreover, try to buy foods that encourage biodiversity, do not involve waste and do not destroy forests. If you want to find out more, go to the responsible sourcing chapter. </p>
        </div>
      </div>
    </div>
  </div>

  <div class=" use-modal">
    <div class="modal-overlay1 modal-toggle12"></div>
    <div class="modal-wrapper1 modal-transition1">
      <button class="modal-close1 modal-toggle12">
        <svg class="icon-close icon" viewBox="0 0 32 32">
          <use xlink:href="#icon-close">
            <g id="icon-close">
              <path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
            </g>
          </use>
        </svg>
      </button>
      <div class="modal-body1">

        <div class="modal-content1 flexi-cont more-text">
          <div>
          <h4>Compost the Scraps</h4>
                <p> Composting can help put food scraps to use and reduce methane emissions in landfills. Fruits, vegetables, coffee and tea all are good materials for compost.</p>


          </div>
        </div>
      </div>
    </div>


    <script>
      var x, i, j, l, ll, selElmnt, a, b, c;
      /*look for any elements with the class "custom-select":*/
      x = document.getElementsByClassName("custom-select");
      l = x.length;
      for (i = 0; i < l; i++) {
        selElmnt = x[i].getElementsByTagName("select")[0];
        ll = selElmnt.length;
        /*for each element, create a new DIV that will act as the selected item:*/
        a = document.createElement("DIV");
        a.setAttribute("class", "select-selected");
        a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
        x[i].appendChild(a);
        /*for each element, create a new DIV that will contain the option list:*/
        b = document.createElement("DIV");
        b.setAttribute("class", "select-items select-hide");
        for (j = 1; j < ll; j++) {
          /*for each option in the original select element,
          create a new DIV that will act as an option item:*/
          c = document.createElement("DIV");
          c.innerHTML = selElmnt.options[j].innerHTML;
          c.addEventListener("click", function(e) {
            /*when an item is clicked, update the original select box,
            and the selected item:*/
            var y, i, k, s, h, sl, yl;
            s = this.parentNode.parentNode.getElementsByTagName("select")[0];
            sl = s.length;
            h = this.parentNode.previousSibling;
            for (i = 0; i < sl; i++) {
              if (s.options[i].innerHTML == this.innerHTML) {
                s.selectedIndex = i;
                h.innerHTML = this.innerHTML;
                y = this.parentNode.getElementsByClassName("same-as-selected");
                yl = y.length;
                for (k = 0; k < yl; k++) {
                  y[k].removeAttribute("class");
                }
                this.setAttribute("class", "same-as-selected");
                break;
              }
            }
            h.click();
          });
          b.appendChild(c);
        }
        x[i].appendChild(b);
        a.addEventListener("click", function(e) {
          /*when the select box is clicked, close any other select boxes,
          and open/close the current select box:*/
          e.stopPropagation();
          closeAllSelect(this);
          this.nextSibling.classList.toggle("select-hide");
          this.classList.toggle("select-arrow-active");
        });
      }

      function closeAllSelect(elmnt) {
        /*a function that will close all select boxes in the document,
        except the current select box:*/
        var x, y, i, xl, yl, arrNo = [];
        x = document.getElementsByClassName("select-items");
        y = document.getElementsByClassName("select-selected");
        xl = x.length;
        yl = y.length;
        for (i = 0; i < yl; i++) {
          if (elmnt == y[i]) {
            arrNo.push(i)
          } else {
            y[i].classList.remove("select-arrow-active");
          }
        }
        for (i = 0; i < xl; i++) {
          if (arrNo.indexOf(i)) {
            x[i].classList.add("select-hide");
          }
        }
      }
      /*if the user clicks anywhere outside the select box,
      then close all select boxes:*/
      document.addEventListener("click", closeAllSelect);



      $('.slider').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        arrows: true,
        dots: false,
        centerMode: true,
        variableWidth: true,
        infinite: true,
        focusOnSelect: true,
        cssEase: 'linear',
        touchMove: true,
        prevArrow: '<button class="slick-prev"> < </button>',
        nextArrow: '<button class="slick-next"> > </button>',

        //         responsive: [                        
        //             {
        //               breakpoint: 576,
        //               settings: {
        //                 centerMode: false,
        //                 variableWidth: false,
        //               }
        //             },
        //         ]
      });



      var imgs = $('.slider img');
      imgs.each(function() {
        var item = $(this).closest('.item');
        item.css({
          'background-image': 'url(' + $(this).attr('src') + ')',
          'background-position': 'center',
          '-webkit-background-size': 'cover',
          'background-size': 'cover',
        });
        $(this).hide();
      });

      $('.slider2').slick({
        slidesToShow: 3,
        arrows: true,
        dots: false,
        centerMode: true,
        variableWidth: true,
        infinite: true,
        focusOnSelect: true,
        cssEase: 'linear',
        touchMove: true,
        prevArrow: '<button class="slick-prev"> < </button>',
        nextArrow: '<button class="slick-next"> > </button>',

        //         responsive: [                        
        //             {
        //               breakpoint: 576,
        //               settings: {
        //                 centerMode: false,
        //                 variableWidth: false,
        //               }
        //             },
        //         ]
      });

      var imgs = $('.slider2 img');
      imgs.each(function() {
        var item = $(this).closest('.item');
        item.css({
          'background-image': 'url(' + $(this).attr('src') + ')',
          'background-position': 'center',
          '-webkit-background-size': 'cover',
          'background-size': 'cover',
        });
        $(this).hide();
      });




      let collapsibleHeaders = document.getElementsByClassName('collapsible__header');

      Array.from(collapsibleHeaders).forEach(header => {
        header.addEventListener('click', () => {
          header.parentElement.classList.toggle('collapsible--open');
        });
      });

      // Quick & dirty toggle to demonstrate modal toggle behavior
      $('.modal-toggle1').on('click', function(e) {
        e.preventDefault();
        $('.vegan-modal').toggleClass('is-visible');
      });
      $('.modal-toggle2').on('click', function(e) {
        e.preventDefault();
        $('.vegi-modal').toggleClass('is-visible');
      });
      $('.modal-toggle3').on('click', function(e) {
        e.preventDefault();
        $('.paleo-modal').toggleClass('is-visible');
      });
      $(' .modal-toggle4').on('click', function(e) {
        e.preventDefault();
        $('.keto-modal').toggleClass('is-visible');
      });
      $('.modal-toggle5').on('click', function(e) {
        e.preventDefault();
        $('.fruit-modal').toggleClass('is-visible');
      });
      $('.modal-toggle6').on('click', function(e) {
        e.preventDefault();
        $('.omni-modal').toggleClass('is-visible');
      });
      $('.modal-toggle7').on('click', function(e) {
        e.preventDefault();
        $('.flexi-modal').toggleClass('is-visible');
      });
      $('.modal-toggle8').on('click', function(e) {
        e.preventDefault();
        $('.eng-modal').toggleClass('is-visible');
      });
      $('.modal-toggle9').on('click', function(e) {
        e.preventDefault();
        $('.redu-modal').toggleClass('is-visible');
      });
      $('.modal-toggle10').on('click', function(e) {
        e.preventDefault();
        $('.intro-modal').toggleClass('is-visible');
      });
      $('.modal-toggle11').on('click', function(e) {
        e.preventDefault();
        $('.source-modal').toggleClass('is-visible');
      });
      $('.modal-toggle12').on('click', function(e) {
        e.preventDefault();
        $('.use-modal').toggleClass('is-visible');
      });

      $('.modal-toggle13').on('click', function(e) {
        e.preventDefault();
        $('.set-modal').toggleClass('is-visible');
      });
      $('.modal-toggle14').on('click', function(e) {
        e.preventDefault();
        $('.ver-modal').toggleClass('is-visible');
      });
      $('.modal-toggle15').on('click', function(e) {
        e.preventDefault();
        $('.exp-modal').toggleClass('is-visible');
      });
      $('.modal-toggle16').on('click', function(e) {
        e.preventDefault();
        $('.neh-modal').toggleClass('is-visible');
      });
      $('.modal-toggle17').on('click', function(e) {
        e.preventDefault();
        $('.setsie-modal').toggleClass('is-visible');
      });

      $('.modal-toggle18').on('click', function(e) {
        e.preventDefault();
        $('.introdiv-modal').toggleClass('is-visible');
      });
    </script>