$(document).ready(function () {
  $("#cp01").click(function () {
    alert("Hallo");
  });
});
